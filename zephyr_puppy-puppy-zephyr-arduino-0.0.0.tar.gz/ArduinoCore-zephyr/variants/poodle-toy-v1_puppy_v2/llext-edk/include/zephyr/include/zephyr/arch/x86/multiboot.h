/*
 * Copyright (c) 2019 Intel Corporation
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ZEPHYR_INCLUDE_ARCH_X86_MULTIBOOT_H_
#define ZEPHYR_INCLUDE_ARCH_X86_MULTIBOOT_H_

#ifndef _ASMLANGUAGE

#include "multiboot_info.h"

extern struct multiboot_info multiboot_info;

#ifdef CONFIG_MULTIBOOT_INFO

void z_multiboot_init(struct multiboot_info *info_pa);

#else

inline void z_multiboot_init(struct multiboot_info *info_pa)
{
	ARG_UNUSED(info_pa);
}

#endif /* CONFIG_MULTIBOOT_INFO */

/*
 * the mmap_addr field points to a series of entries of the following form.
 */

struct multiboot_mmap {
	uint32_t size;
	uint64_t base;
	uint64_t length;
	uint32_t type;
} __packed;

#endif /* _ASMLANGUAGE */

/* Boot type value (see prep_c.c) */
#define MULTIBOOT_BOOT_TYPE 1

/*
 * Possible values for multiboot_mmap.type field.
 * Other values should be assumed to be unusable ranges.
 */

#define MULTIBOOT_MMAP_RAM		1
#define MULTIBOOT_MMAP_ACPI		3
#define MULTIBOOT_MMAP_NVS		4
#define MULTIBOOT_MMAP_DEFECTIVE	5

/*
 * Magic numbers: the kernel multiboot header (see crt0.S) begins with
 * MULTIBOOT_HEADER_MAGIC to signal to the booter that it supports
 * multiboot. On kernel entry, EAX is set to MULTIBOOT_EAX_MAGIC to
 * signal that the boot loader is multiboot compliant.
 */

#define MULTIBOOT_HEADER_MAGIC		0x1BADB002
#define MULTIBOOT_EAX_MAGIC		0x2BADB002

/*
 * Typically, we put no flags in the multiboot header, as it exists solely
 * to reassure the loader that we're a valid binary. The exception to this
 * is when we want the loader to configure the framebuffer for us.
 */

#define MULTIBOOT_HEADER_FLAG_MEM	BIT(1)
#define MULTIBOOT_HEADER_FLAG_FB	BIT(2)

#ifdef CONFIG_INTEL_MULTIBOOTFB_DISPLAY
#define MULTIBOOT_HEADER_FLAGS \
	(MULTIBOOT_HEADER_FLAG_FB | MULTIBOOT_HEADER_FLAG_MEM)
#else
#define MULTIBOOT_HEADER_FLAGS MULTIBOOT_HEADER_FLAG_MEM
#endif

/* The flags in the boot info structure tell us which fields are valid. */

#define MULTIBOOT_INFO_FLAGS_MEM		BIT(0)
#define MULTIBOOT_INFO_FLAGS_CMDLINE		BIT(2)
#define MULTIBOOT_INFO_FLAGS_MMAP		BIT(6)
#define MULTIBOOT_INFO_FLAGS_FB			BIT(12)

/* The only fb_type we support is RGB. No text modes and no color palettes. */

#define MULTIBOOT_INFO_FB_TYPE_RGB	1

#endif /* ZEPHYR_INCLUDE_ARCH_X86_MULTIBOOT_H_ */
